/**  
* Nicolas Schoenrock - nvschoenrock@dmacc.edu 
* CIS153 <14354>
* Sep 26, 2025 
* Description: 
 
* OS: [Windows 11]
* IDE: [eclipse 2023]
* Copyright : This is my own original work 
* based on specifications issued by our instructor
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or
* unmodified, nor used generative AI as a final draft. 
* I have not given other fellow student(s) access to my program.

*/ 
package linkedListImplementationTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import linkedListImplementation.LinkedList;
import linkedListImplementation.LinkedList.*;
import linkedListImplementation.LinkedListEmptyException;
import linkedListImplementation.LinkedListFullException;

/**
 * 
 */
class LinkedListTests {

	/**
	 * Test method for {@link linkedListImplementation.LinkedList#LinkedList()}.
	 */
	@Test
	void testLinkedList() {
		LinkedList testList = new LinkedList();
		
		
		assertTrue(testList.isEmpty());
	}

	
	/**
	 * Test method for {@link linkedListImplementation.LinkedList#size()}.
	 * @throws LinkedListFullException 
	 */
	@Test
	void testSize() throws LinkedListFullException {
		LinkedList testList = new LinkedList();
		int listItem1 = 45;
		
		testList.insertLast(listItem1);
		
		int expectedVal = 1;
		int actualVal = testList.size();
		
		assertEquals(expectedVal, actualVal);
	}

	/**
	 * Test method for {@link linkedListImplementation.LinkedList#insertLast(int)}.
	 * @throws LinkedListFullException 
	 */
	@Test
	void testInsertLast() throws LinkedListFullException {
		LinkedList testList = new LinkedList();
		String listItem1 = "String1";
		
		testList.insertLast(listItem1);
		
		double listItem2 = 57.5;
		testList.insertLast(listItem2);
		
		int listItem3 = 84;
		testList.insertLast(listItem3);
		
		double listItem4 = 4.56;
		testList.insertLast(listItem4);
		

		double expectedVal = 4;
		int actualVal = testList.size();
		
		assertEquals(expectedVal, actualVal);		
		
	}
	@Test
	void testInsertLastFull() throws LinkedListFullException {
		LinkedList testList = new LinkedList(4);
		String listItem1 = "String1";
		testList.insertLast(listItem1);
		double listItem2 = 57.5;
		testList.insertLast(listItem2);
		int listItem3 = 84;
		testList.insertLast(listItem3);
		double listItem4 = 4.56;
		testList.insertLast(listItem4);
		

		
	
		assertThrows(LinkedListFullException.class,()-> testList.insertLast(67) );

	}

	/**
	 * Test method for {@link linkedListImplementation.LinkedList#removeFirst()}.
	 * @throws LinkedListEmptyException 
	 * @throws LinkedListFullException 
	 */
	@Test
	void testRemoveFirst() throws LinkedListEmptyException, LinkedListFullException {
		LinkedList testList = new LinkedList();
		String listItem1 = "String1";
		
		testList.insertLast(listItem1);
		
		Double listItem2 = 57.5;
		testList.insertLast(listItem2);
		
		int listItem3 = 84;
		testList.insertLast(listItem3);
		
		double listItem4 = 4.56;
		testList.insertLast(listItem4);
		

		int expectedSizeVal = 3;
		String expectedHeadVal = "String1";
		
		String actualRemovedVal = (String)testList.removeFirst();
		
		int actualSizeVal = testList.size();
		
		assertEquals(expectedSizeVal, actualSizeVal);	
		assertEquals(expectedHeadVal, actualRemovedVal);
		}
	@Test
	void testRemoveEmpty() {
		LinkedList testList = new LinkedList(5);
		assertThrows(LinkedListEmptyException.class,()-> testList.removeFirst());
		
	}

	/**
	 * Test method for {@link linkedListImplementation.LinkedList#isFull()}.
	 * @throws LinkedListFullException 
	 */
	@Test
	void testIsFull() throws LinkedListFullException {
		
		LinkedList testList = new LinkedList(5);
		String item1 = "String1";
		String item2 = "String2";
		String item3 = "String3";
		String item4 = "String4";
		String item5 = "String5";
		
		testList.insertLast(item1);
		testList.insertLast(item2);
		testList.insertLast(item3);
		testList.insertLast(item4);
		testList.insertLast(item5);
		
		assertEquals(true, testList.isFull());


	}
	
	@Test
	void testIsFullFalse() throws LinkedListFullException {
		
		LinkedList testList = new LinkedList(5);
		String item1 = "String1";
		String item2 = "String2";
		String item3 = "String3";
		String item4 = "String4";
		
		testList.insertLast(item1);
		testList.insertLast(item2);
		testList.insertLast(item3);
		testList.insertLast(item4);
		
		assertEquals(false, testList.isFull());


	}

	/**
	 * Test method for {@link linkedListImplementation.LinkedList#isEmpty()}.
	 */
	@Test
	void testIsEmpty() {
		LinkedList testList = new LinkedList(5);
		assertEquals(true, testList.isEmpty());
		
	}
	void testIsEmptyFalse() throws LinkedListFullException {
		
		LinkedList testList = new LinkedList(5);
		String item1 = "String1";
		String item2 = "String2";
		String item3 = "String3";
		String item4 = "String4";
		
		testList.insertLast(item1);
		testList.insertLast(item2);
		testList.insertLast(item3);
		testList.insertLast(item4);
		
		assertEquals(false, testList.isEmpty());


	}
	
	@Test
	void testPrintFull() throws LinkedListEmptyException, LinkedListFullException {
		LinkedList testList = new LinkedList(5);
		String item1 = "String1";
		String item2 = "String2";
		String item3 = "String3";
		String item4 = "String4";
		String item5 = "String5";
		
		testList.insertLast(item1);
		testList.insertLast(item2);
		testList.insertLast(item3);
		testList.insertLast(item4);
		testList.insertLast(item5);
		
		String expectedVal = "String1, String2, String3, String4, String5";
		assertEquals(expectedVal, testList.print());
		
	}
	@Test
	void testPrint() throws LinkedListEmptyException, LinkedListFullException {
		LinkedList testList = new LinkedList(5);
		String item1 = "String1";
		String item2 = "String2";
		String item3 = "String3";

		
		testList.insertLast(item1);
		testList.insertLast(item2);
		testList.insertLast(item3);
		
		String expectedVal = "String1, String2, String3";
		assertEquals(expectedVal, testList.print());
		
	}
	@Test
	void testPrintEmpty() {
		LinkedList testList = new LinkedList(5);
		assertThrows(LinkedListEmptyException.class,()-> testList.print());
		
	}

	/**
	 * Test method for {@link linkedListImplementation.LinkedList#get(int)}.
	 * @throws LinkedListEmptyException 
	 * @throws LinkedListFullException 
	 */
	@Test
	void testGet() throws LinkedListEmptyException, LinkedListFullException {
		
		LinkedList testList = new LinkedList();
		int listItem1 = 45;
		
		testList.insertLast(listItem1);
		
		int listItem2 = 57;
		testList.insertLast(listItem2);
		
		int listItem3 = 84;
		testList.insertLast(listItem3);
		

		int expectedVal = 84;
		int actualVal = (int)testList.get(expectedVal);
		
		assertEquals(expectedVal, actualVal);
		
	}
	@Test
	void testGetEmpty() {
		LinkedList testList = new LinkedList(5);
		assertThrows(LinkedListEmptyException.class,()-> testList.get(45));
		
	}

}
