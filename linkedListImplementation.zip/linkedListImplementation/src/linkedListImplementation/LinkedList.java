/**  
* Nicolas Schoenrock - nvschoenrock@dmacc.edu 
* CIS153 <14354>
* Sep 25, 2025 
* Description: 
 
* OS: [Windows 11]
* IDE: [eclipse 2023]
* Copyright : This is my own original work 
* based on specifications issued by our instructor
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or
* unmodified, nor used generative AI as a final draft. 
* I have not given other fellow student(s) access to my program.

*/
package linkedListImplementation;

import java.util.ArrayList;

/**
 * 
 */
public class LinkedList {

	/**
	 * @param args
	 */
	private int maxSize;
	private int size;
	private Node head;

	public LinkedList() {
		maxSize = 10;
		size = 0;
	}
	/**
	 * @param int value representing the max size of the list;
	 */
	public LinkedList(int maxSize) {
		this.maxSize = maxSize;
		size = 0;
	}

	public int size() {
		return this.size;
	}
	/**
	 * @param Object, covers most input and allows the linked list to store multiple data types
	 */
	public void insertLast(Object data) throws LinkedListFullException {
		if (this.isFull()) {
			throw new LinkedListFullException();
		}

		Node tempNode = new Node(data);
		if (head == null) {
			this.head = tempNode;
		}
		// else if(head.next == null) {

		// }
		else {
			Node nextNode = head;
			while (nextNode.next != null) {
				nextNode = nextNode.next;
			}
			nextNode.next = tempNode;
		}
		size++;
	}
	/**
	 * @return Object data containing a value
	 */
	public Object removeFirst() throws LinkedListEmptyException {
		if (this.isEmpty()) {
			throw new LinkedListEmptyException();
		}
		Node tempNode = head;
		head = tempNode.next;
		size--;

		return tempNode.data;
	}
	/**
	 * @return boolean based on whether the LinkedList is full
	 */
	public boolean isFull() {
		return size == maxSize;
	}
	/**
	 * @return boolean based on whether the LinkedList is empty
	 */
	public boolean isEmpty() {
		return head == null;
	}
	/**
	 * @param Object, key representing a value to search the list for
	 * @return Object, returns the first instance of that value
	 */
	public Object get(Object key) throws LinkedListEmptyException {
		if (this.isEmpty()) {
			throw new LinkedListEmptyException();
		}
		Node tempNode = head;

		while (!(tempNode.data.equals(key))) {
			tempNode = tempNode.next;
		}
		return tempNode.data;

	}
	/**
	 * @return String, returns list items in string format
	 */
	public String print() throws LinkedListEmptyException {
		if (this.isEmpty()) {
			throw new LinkedListEmptyException();
		}

		Node tempNode = head;
		String output = "";
		while (tempNode.next != null) {
			output += tempNode.data + ", ";
			tempNode = tempNode.next;
			if (tempNode.next == null) {
				output += tempNode.data;
			}

		}

		return output;
	}

	/*
	 * public static void main(String[] args) throws LinkedListFullException { //
	 * TODO Auto-generated method stub LinkedList testList = new LinkedList(); int
	 * listItem1 = 45;
	 * 
	 * testList.insertLast(listItem1);
	 * 
	 * String listItem2 = "String of 57"; testList.insertLast(listItem2);
	 * 
	 * int listItem3 = 84; testList.insertLast(listItem3);
	 * 
	 * 
	 * //int expectedVal = 84; //Object actualVal = testList.get(expectedVal);
	 * //System.out.println(testList.get(expectedVal));
	 * //System.out.print(testList.print()); }
	 */

}
