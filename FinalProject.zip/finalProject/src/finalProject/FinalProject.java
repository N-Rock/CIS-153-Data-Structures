/**  
* Nicolas Schoenrock - nvschoenrock@dmacc.edu 
* CIS153 <14354>
* Nov 16, 2025 
* Description: 
 
* OS: [Windows 11]
* IDE: [eclipse 2023]
* Copyright : This is my own original work 
* based on specifications issued by our instructor
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or
* unmodified, nor used generative AI as a final draft. 
* I have not given other fellow student(s) access to my program.

*/
package finalProject;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import javax.swing.*;

import view.MainDBWindow;

import java.util.Map.Entry;
import java.util.Set;

/**
 * 
 */

public class FinalProject {

	public static <K, V> String displayDB(Dictionary<Integer, Item> dbTable) {
		//list of fields pulled from the items, displayed at the top of the end String.
		List<String> fields = new ArrayList<String>();
		
		HashMap<Integer, Object> itemValues = new HashMap<>();
		
		String fieldString = "";
		String itemString ="";
		
		//iterating through outer database dictionary
		Enumeration<Integer> keys = dbTable.keys();
		while (keys.hasMoreElements()) {
			int key = keys.nextElement();
		
			//iterating through the item for the current dictionary entry
			//Enumeration<String> itemKeys = dbTable.get(key).getAttributes().keySet();
			
			//while (itemKeys.hasMoreElements()) {
			for(String itemKey : dbTable.get(key).getAttributes().keySet()) {
				//String itemKey = itemKeys.nextElement();
				if (!fields.contains(itemKey.toLowerCase())) {
					fields.add(itemKey);
				}
			}
			
			//fields.contains(itemMapEntry.getKey())
		}
		
		
		//re-iterating through the items with the fields list filled so it can formatt properly
		keys = dbTable.keys();
		while(keys.hasMoreElements()) {
			int key = keys.nextElement();
			
			for(int i = 0; i < fields.size(); i++) {
				if(dbTable.get(key).getAttributes().get(fields.get(i)) != null) {
					itemValues.put(i, dbTable.get(key).getAttributes().get(fields.get(i)));
				}
				else {
					itemValues.put(i, "N/A");
				}
				itemString += itemValues.get(i) + "  ";
			}
			itemString += "\n";
		
			//System.out.println(fields + "\n " + itemValues);
		}
		for(String field : fields) {
			fieldString += field + "  ";
		}
		
		//System.out.println(fields);

		String display = fieldString + "\n------------------------------------------------------------------------\n" 
				+ itemString;
		return display;
	}

	public static boolean addItem(Dictionary<Integer, Item> database, Item item) {
		
		
		try{
			int currentDBID = database.size();
			item.setId(currentDBID);
			database.put(currentDBID, item);
			
		}catch(Exception e){
			return false;
		}
		
		return true;

	}

	/**
	 * 
	 */
	public static void mergeArray(int[] array, int left, int mid, int right) {
		
		int arrSize1 = mid - left + 1;
		int arrSize2 = right - mid;
		
		int lArr[] = new int [arrSize1];
		int rArr[] = new int [arrSize2];
		
		for(int i = 0; i < arrSize1; i++) {
			lArr[i] = array[left + i];
		}
		for(int n = 0; n < arrSize2; n++) {
			rArr[n] = array[mid + 1 + n];

		}
		
		int v =0; 
		int j=0;
		int k =left;
		
		while(v < arrSize1 && j < arrSize2) {
			if(lArr[v]<= rArr[j]) {
				array[k] = lArr[v];
				v++;
			}
			else {
				array[k] = rArr[j];
				j++;
			}
			k++;
		}
		
		while(v<arrSize1) {
			array[k] = lArr[v];
			v++;
			k++;
		}
		
		while(j<arrSize2) {
			array[k] = rArr[j];
			j++;
			k++;
		}
	}
	public static void mergeSort(int array[], int left, int right) {
		if(left < right) {
			int mid = left + (right - left) /2;
			
			mergeSort(array, left, mid);
			mergeSort(array, mid + 1, right);
			
			mergeArray(array, left, mid, right);
		}
	}

	/**
	 * @param args
	 */
	
	
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Dictionary<Integer, Item> database = new Hashtable<>();
		Tuple<String, Double> tuple1 = new Tuple<String, Double>("price", 86.94);
		Tuple<String, Double> tuple2 = new Tuple<String, Double>("weight", 16.94);
		Tuple<String, String> tuple3 = new Tuple<String, String>("condition", "New");
		Tuple<String, String> tuple4 = new Tuple<String, String>("Dept.", "Hardware");
		Tuple<String, Integer> tuple5 = new Tuple<String, Integer>("dept.#", 24);


		Item item1 = new Item("item1", tuple1);
		item1.addField("Condition", "Refurbished");
		item1.addField("Weight", 16.94);
		Item item2 = new Item("item2", tuple2, tuple3);
		Item item3 = new Item("item3", tuple3, tuple4, tuple5);
		
		addItem(database, item1);
		addItem(database, item2);
		addItem(database, item3);

		

		System.out.println(displayDB(database));
		
		// frame and panel creation 
		JFrame frame = new JFrame();
		MainDBWindow panel = new MainDBWindow(database, frame);
		frame.add(panel);

		frame.setSize(700, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // making sure the program actually exits when you close
		frame.setVisible(true);
	}

}
