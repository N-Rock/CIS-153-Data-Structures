/**  
* Nicolas Schoenrock - nvschoenrock@dmacc.edu 
* CIS153 <14354>
* Dec 8, 2025 
* Description: 
 
* OS: [Windows 11]
* IDE: [eclipse 2023]
* Copyright : This is my own original work 
* based on specifications issued by our instructor
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or
* unmodified, nor used generative AI as a final draft. 
* I have not given other fellow student(s) access to my program.

*/ 
package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Comparator;

import org.junit.jupiter.api.Test;

import finalProject.FinalProject;

/**
 * 
 */
class FinalProjectUnitTests {

	@Test
	void testMergeSort() {
		int[] actual = new int[] {3,29,45,62,5,9,10,85};
		int[] expected = new int[]{3,5,9,10,29,45,62,85};
		
		FinalProject.mergeSort(actual, 0, actual.length -1);
		//System.out.print(actual);
		
		
		for(int i = 0; i < actual.length; i++) {
			assertTrue(Integer.compare(actual[i], expected[i]) == 0);
		}
		//assertEquals(expected, actual);
		
		
		
	}

}
