/**  
* Nicolas Schoenrock - nvschoenrock@dmacc.edu 
* CIS153 <14354>
* Dec 2, 2025 
* Description: 
 
* OS: [Windows 11]
* IDE: [eclipse 2023]
* Copyright : This is my own original work 
* based on specifications issued by our instructor
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or
* unmodified, nor used generative AI as a final draft. 
* I have not given other fellow student(s) access to my program.

*/ 
package view;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.List;
import java.util.Map.Entry;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;

import finalProject.*;
/**
 * 
 */
public class AddEditPanel extends JPanel {
	//Overall/miscellaneous components
	Dictionary<Integer, Item> database;
	JLabel locationLabel = new JLabel("Add/Edit database item");
	JFrame parentFrame;
	BoxLayout addEditBox = new BoxLayout(this, BoxLayout.Y_AXIS);

	//top and bottom row
	JComboBox<Item> selectedItem;
	JButton backButton;
	
	//middle rows for adding/viewing items.
	JTextField itemInput;
	JTextField itemFieldInput;
	JButton itemSubmitButton;
	JComboBox<String> itemFields;
	JComboBox<Class<?>> typeCBox;
	JTextPane dbDisplayView;
	JScrollPane displayScroll;

	
	public AddEditPanel(Dictionary<Integer, Item> database, JFrame parentFrame) {
		//database initialization
		this.database = database;
		this.parentFrame = parentFrame;
		
		//setting up a combo box for type casting later
		Class<?> types[] = {Integer.class, String.class, double.class, Boolean.class, char.class};
		typeCBox = new JComboBox<Class<?>>(types);
		
		//database items list setup
		selectedItem = new JComboBox <Item>();
		Enumeration<Integer> keys = database.keys();
		while(keys.hasMoreElements()) {
			int key = keys.nextElement();
			//Tuple<?,?> tmpKeyValPair = new Tuple(database.get(key).getName() + " (ID: " + key + ")", database.get(key));
			selectedItem.addItem(database.get(key)); 
		}
		
		//initialization for the item fields comboBox
		itemFields = new JComboBox<String>();
		ComboBoxListener addEditCBListen = new ComboBoxListener();
		selectedItem.addActionListener(addEditCBListen);
		
		 itemInput = new JTextField();
		 itemInput.setSize(200, 100);
		 itemFieldInput = new JTextField();
		 itemFieldInput.setVisible(false);
		 itemSubmitButton = new JButton("Submit");
		 
		 itemFields.addActionListener(addEditCBListen);
		
		 this.setLayout(addEditBox);
		
		//setting up the panels
		
		 JPanel row1 = new JPanel();
		 row1.setLayout(new BoxLayout(row1, BoxLayout.X_AXIS));
		 JLabel itemTag = new JLabel("Item: ");
		 row1.add(Box.createRigidArea(new Dimension(70, 25)));
		 row1.add(itemTag);
		 row1.add(selectedItem);
		 row1.add(Box.createRigidArea(new Dimension(70, 25)));
		 add(row1);
		 
		 JPanel row2 = new JPanel();
		 row2.setLayout(new BoxLayout(row2, BoxLayout.X_AXIS));
		 row2.add(Box.createRigidArea(new Dimension(70, 25)));
		 JLabel fieldsTag = new JLabel("Fields: " );
		 row2.add(fieldsTag);
		 itemFields.setPreferredSize(getPreferredSize());
		 row2.add(itemFields);
		 row2.add(itemFieldInput);
		 row2.add(itemInput);
		 row2.add(typeCBox);
		 row2.add(itemSubmitButton);
		 row2.add(Box.createRigidArea(new Dimension(70, 25)));
		 add(row2);
		 
		 
		 

		
		 JPanel row3 = new JPanel();
		 row3.setLayout(new BoxLayout(row3, BoxLayout.X_AXIS));
		//creating a Display window
		dbDisplayView = new JTextPane();
		dbDisplayView.setEditable(false);
		dbDisplayView.setPreferredSize(new Dimension(1000, 1000));
		displayScroll = new JScrollPane(dbDisplayView);
		
		row3.add(Box.createRigidArea(new Dimension(70, 25)));
		row3.add(displayScroll);
		row3.add(Box.createRigidArea(new Dimension(70, 25)));
		add(row3);
		
		
		
		ButtonListener backToMain = new ButtonListener();
		backButton = new JButton("Back");
		backButton.addActionListener(backToMain);
		JPanel row4 = new JPanel();
		row4.setLayout(new BoxLayout(row4, BoxLayout.X_AXIS));
		row4.add(backButton);
		add(row4);
		
		
		 itemSubmitButton.addActionListener(backToMain);

		
		parentFrame.pack();
		parentFrame.setLocationRelativeTo(null);
		
	}
	private void swapPanels(JPanel nextPanel) {
		removeAll();
		setVisible(false);
		add(nextPanel);
		validate();
		setVisible(true);
	}
	class ButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// if statement checking the source of the action and acting accordingly
			if (e.getSource() == backButton) {
				JPanel nextPanel = new MainDBWindow(database, parentFrame);
				swapPanels(nextPanel);
			}
			else if (e.getSource() == itemSubmitButton) {
				Item tmpItem = (Item)selectedItem.getSelectedItem();
				Object itemValue = null;
				try {
					itemValue = itemInput.getText();
					((Class<?>) typeCBox.getSelectedItem()).cast(itemValue);
				}catch(Exception ex) {
					System.out.println(ex.getMessage());
				}
				
				database.get(tmpItem.getId()).addField(itemFieldInput.getText(), itemValue);
				
				dbDisplayView.setText(FinalProject.displayDB(database));
				dbDisplayView.revalidate();
				dbDisplayView.repaint();
			}

		}

	}
	
	class ComboBoxListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == selectedItem) {
				Item tempItem = (Item) selectedItem.getSelectedItem();
				itemFields.removeAllItems();
				for(Entry<String, Object> tmpEntry : tempItem.getAttributes().entrySet() ) {
					itemFields.addItem(tmpEntry.getKey());
					
				}
				itemFields.addItem("New Field");
				
			}
			else if(e.getSource() == itemFields) {
				if(itemFields.getSelectedItem() == "New Field") {
					itemFieldInput.setVisible(true);
				}
			}
		}
	}
}
