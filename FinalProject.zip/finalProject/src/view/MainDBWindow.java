package view;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;

import finalProject.FinalProject;
import finalProject.Item;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.text.DecimalFormat;
import java.util.Dictionary;

import javax.swing.JLabel;

/**
 * Nicolas Schoenrock - nvschoenrock@dmacc.edu CIS153 <14354> Dec 1, 2025
 * Description:
 * 
 * OS: [Windows 11] IDE: [eclipse 2023] Copyright : This is my own original work
 * based on specifications issued by our instructor Academic Honesty: I attest
 * that this is my original work. I have not used unauthorized source code,
 * either modified or unmodified, nor used generative AI as a final draft. I
 * have not given other fellow student(s) access to my program.
 * 
 */

public class MainDBWindow extends JPanel {

	Dictionary<Integer, Item> database;
	JLabel locationLabel;
	GridLayout mainWinLayout = new GridLayout(3, 3, 5, 5);
	BorderLayout mainWinLayoutB;
	JButton addEditButton;
	JFrame parentFrame;

	public MainDBWindow(Dictionary<Integer, Item> sourceDB, JFrame parentFrame) {
		super();
		this.database = sourceDB;
		this.parentFrame = parentFrame;

		ButtonListener mainWinButtonListen = new ButtonListener();

		// subPanel initialization
		JPanel gridTopL = new JPanel();
		JPanel gridTopM = new JPanel();
		JPanel gridTopR = new JPanel();
		JPanel gridMidL = new JPanel();
		JPanel gridCenter = new JPanel();
		JPanel gridMidR = new JPanel();
		JPanel gridLowL = new JPanel();
		JPanel gridLowM = new JPanel();
		JPanel gridLowR = new JPanel();
		JLabel locationLabel = new JLabel("Database View");

		/*
		 * Display window setup. This should be where the active database query is.
		 * 
		 */
		JPanel displayWindow = new JPanel();
		JTextPane dbDisplayView = new JTextPane();
		dbDisplayView.setEditable(false);
		dbDisplayView.setSize(1000, 1000);
		Style dbWinStyle = dbDisplayView.addStyle("Center", null);
		StyleConstants.setAlignment(dbWinStyle, StyleConstants.ALIGN_CENTER);
		dbDisplayView.setText(FinalProject.displayDB(this.database));

		dbDisplayView.setParagraphAttributes(dbWinStyle, true);
		gridTopM.add(locationLabel, BorderLayout.NORTH);
		displayWindow.add(dbDisplayView);

		addEditButton = new JButton("Add/Edit item");

		gridMidL.add(addEditButton);
		addEditButton.addActionListener(mainWinButtonListen);

		this.setLayout(mainWinLayout);

		// Adding the Panels to the layout
		gridCenter.add(displayWindow);

		add(gridTopL);
		add(gridTopM);
		add(gridTopR);
		add(gridMidL);
		add(gridCenter);
		add(gridMidR);
		add(gridLowL);
		add(gridLowM);
		add(gridLowR);
		
		parentFrame.pack();
		parentFrame.setLocationRelativeTo(null);


	}

	/**
	 * @return
	 */
	private LayoutManager mainWinLayout() {
		// TODO Auto-generated method stub
		return null;
	}

	class ButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// if statement checking the source of the action and acting accordingly
			if (e.getSource() == addEditButton) {
				JPanel nextPanel = new AddEditPanel(database, parentFrame);
				swapPanels(nextPanel);
			}

		}

	}
	
	private void swapPanels(JPanel nextPanel) {
		removeAll();
		setVisible(false);
		add(nextPanel);
		validate();
		setVisible(true);
	}

}

