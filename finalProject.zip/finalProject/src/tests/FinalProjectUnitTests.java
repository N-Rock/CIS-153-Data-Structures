/**  
* Nicolas Schoenrock - nvschoenrock@dmacc.edu 
* CIS153 <14354>
* Dec 8, 2025 
* Description: 
 
* OS: [Windows 11]
* IDE: [eclipse 2023]
* Copyright : This is my own original work 
* based on specifications issued by our instructor
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or
* unmodified, nor used generative AI as a final draft. 
* I have not given other fellow student(s) access to my program.

*/ 
package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Dictionary;
import java.util.Hashtable;

import org.junit.jupiter.api.Test;

import finalProject.FinalProject;
import finalProject.Item;
import finalProject.Tuple;

/**
 * 
 */
class FinalProjectUnitTests {

	@Test
	void testMergeSort() {
		Object[] actual = new Object[] {3,29,45,62,5,9,10,85};
		Object[] expected = new Object[]{3,5,9,10,29,45,62,85};
		
		FinalProject.mergeSort(actual, 0, actual.length -1);
		//System.out.print(actual);
		
		
		for(int i = 0; i < actual.length; i++) {
			assertTrue(Integer.compare((int)actual[i], (int)expected[i]) == 0);
		}
		//assertEquals(expected, actual);
		
		
		
	}
	@Test
	void testDBAddItem() {
		Dictionary<Integer, Item> database = new Hashtable<>();
		Tuple<String, Double> tuple1 = new Tuple<String, Double>("price", 86.94);
		Tuple<String, Double> tuple2 = new Tuple<String, Double>("weight", 16.94);
		Tuple<String, String> tuple3 = new Tuple<String, String>("condition", "New");
		Tuple<String, String> tuple4 = new Tuple<String, String>("Dept.", "Hardware");
		Tuple<String, Integer> tuple5 = new Tuple<String, Integer>("dept.#", 24);
		
		Item item1 = new Item("item1", tuple1);
		item1.addField("Condition", "Refurbished");
		item1.addField("Weight", 16.94);
		Item item2 = new Item("item2", tuple2, tuple3);
		Item item3 = new Item("item3", tuple3, tuple4, tuple5);
		
		FinalProject.addItem(database, item1);
		FinalProject.addItem(database, item2);
		FinalProject.addItem(database, item3);
		
		assertEquals(2, database.get(2).getId());
		assertEquals(3, database.size());
	}
	
	

}
