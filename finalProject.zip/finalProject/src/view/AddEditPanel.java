/**  
* Nicolas Schoenrock - nvschoenrock@dmacc.edu 
* CIS153 <14354>
* Dec 2, 2025 
* Description: 
 
* OS: [Windows 11]
* IDE: [eclipse 2023]
* Copyright : This is my own original work 
* based on specifications issued by our instructor
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or
* unmodified, nor used generative AI as a final draft. 
* I have not given other fellow student(s) access to my program.

*/ 
package view;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.List;
import java.util.Map.Entry;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;

import finalProject.*;
/**
 * 
 */
public class AddEditPanel extends JPanel {
	//Overall/miscellaneous components
	Dictionary<Integer, Item> database;
	JLabel locationLabel = new JLabel("Add/Edit database item");
	JFrame parentFrame;
	BoxLayout addEditBox = new BoxLayout(this, BoxLayout.Y_AXIS);

	//top and bottom row
	JComboBox<Object> selectedItem;
	JButton backButton;
	
	//middle rows for adding/viewing items.
	JTextField itemNameInput;
	JTextField itemInput;
	JTextField itemFieldInput;
	JComboBox<String> itemFields;
	JComboBox<Class<?>> typeCBox;
	JTextPane dbDisplayView;
	JScrollPane displayScroll;
	boolean addField = false;
	boolean addItemBool = false;
	
	//comittal rows
	JButton deleteItemButton;
	JButton deleteFieldButton;
	JButton itemSubmitButton;
	

	
	public AddEditPanel(Dictionary<Integer, Item> database, JFrame parentFrame) {
		//database initialization
		this.database = database;
		this.parentFrame = parentFrame;
		
		//setting up a combo box for type casting later
		Class<?> types[] = {Integer.class, String.class, double.class, Boolean.class, char.class};
		typeCBox = new JComboBox<Class<?>>(types);
		
		//database items list setup
		selectedItem = new JComboBox <Object>();
		populateItemBox();
		selectedItem.addItem("Add Item");
		
		//initialization for the item fields comboBox
		itemFields = new JComboBox<String>();
		ComboBoxListener addEditCBListen = new ComboBoxListener();
		selectedItem.addActionListener(addEditCBListen);
		 
		 itemNameInput = new JTextField();
		 itemInput = new JTextField();
		 itemInput.setSize(200, 100);
		 itemFieldInput = new JTextField();
		 itemFieldInput.setVisible(false);
		 itemSubmitButton = new JButton("Submit");
		 deleteItemButton = new JButton("Delete Item");
		 deleteFieldButton = new JButton("Remove Field");
		 
		 itemFields.addActionListener(addEditCBListen);
		
		 this.setLayout(addEditBox);
		
		//setting up the panels
		
		 JPanel row1 = new JPanel();
		 row1.setLayout(new BoxLayout(row1, BoxLayout.X_AXIS));
		 JLabel itemTag = new JLabel("Item: ");
		 row1.add(Box.createRigidArea(new Dimension(70, 25)));
		 row1.add(itemTag);
		 row1.add(selectedItem);
		 row1.add(Box.createRigidArea(new Dimension(70, 25)));
		 add(row1);
		 
		 JPanel row2 = new JPanel();
		 row2.setLayout(new BoxLayout(row2, BoxLayout.X_AXIS));
		 row2.add(Box.createRigidArea(new Dimension(70, 25)));
		 row2.add(itemNameInput);
		 JLabel fieldsTag = new JLabel("Fields: " );
		 row2.add(fieldsTag);
		 itemFields.setPreferredSize(getPreferredSize());
		 row2.add(itemFields);
		 row2.add(itemFieldInput);
		 row2.add(itemInput);
		 row2.add(typeCBox);
		 row2.add(Box.createRigidArea(new Dimension(70, 25)));
		 add(row2);
		 
		 //row for submission and removal
		 JPanel row3 = new JPanel();
		 row3.setLayout(new BoxLayout(row3, BoxLayout.X_AXIS));
		 row3.add(itemSubmitButton);
		 row3.add(deleteFieldButton);
		 row3.add(deleteItemButton);
		 
		 add(row3);
		 

		 
		 JPanel row4 = new JPanel();
		 row4.setLayout(new BoxLayout(row4, BoxLayout.X_AXIS));
		//creating a Display window
		dbDisplayView = new JTextPane();
		dbDisplayView.setEditable(false);
		dbDisplayView.setPreferredSize(new Dimension(1000, 1000));
		displayScroll = new JScrollPane(dbDisplayView);
		
		row4.add(Box.createRigidArea(new Dimension(70, 25)));
		row4.add(displayScroll);
		row4.add(Box.createRigidArea(new Dimension(70, 25)));
		add(row4);
		
		
		
		ButtonListener addEditButtonLisener = new ButtonListener();
		backButton = new JButton("Back");
		backButton.addActionListener(addEditButtonLisener);
		JPanel row5 = new JPanel();
		row5.setLayout(new BoxLayout(row5, BoxLayout.X_AXIS));
		row5.add(backButton);
		add(row5);
		
		
		itemSubmitButton.addActionListener(addEditButtonLisener);
		deleteFieldButton.addActionListener(addEditButtonLisener);
		deleteItemButton.addActionListener(addEditButtonLisener);

		
		parentFrame.pack();
		parentFrame.setLocationRelativeTo(null);
		
	}
	
	private void populateItemBox() {
		selectedItem.removeAllItems();
		selectedItem.addItem(null);
		Enumeration<Integer> keys = database.keys();
		while(keys.hasMoreElements()) {
			int key = keys.nextElement();
			selectedItem.addItem(database.get(key)); 
		}
	}
	
	private void swapPanels(JPanel nextPanel) {
		removeAll();
		setVisible(false);
		add(nextPanel);
		validate();
		setVisible(true);
	}
	class ButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// if statement checking the source of the action and acting accordingly
			if (e.getSource() == backButton) {
				JPanel nextPanel = new MainDBWindow(database, parentFrame);
				swapPanels(nextPanel);
			}
			else if (e.getSource() == itemSubmitButton) {
				
				try {
					Item tmpItem = null;
					Object itemValue = null;
					
					if(addItemBool) {
						tmpItem  = new Item(itemNameInput.getText());
						FinalProject.addItem(database, tmpItem);
						
					}else {
						
						tmpItem = (Item)selectedItem.getSelectedItem();
						itemValue = null;
						((Class<?>) typeCBox.getSelectedItem()).cast(itemValue);
					}
					itemValue = itemInput.getText();

					
					if(addField) {
						database.get(tmpItem.getId()).addField(itemFieldInput.getText(), itemValue);
					}
					else {
						database.get(tmpItem.getId()).addField((String) itemFields.getSelectedItem(), itemValue);
					}
					
					if(addItemBool) {
						populateItemBox();
					}
				}catch(Exception ex) {
					System.out.println(ex.getMessage());
				}
				
				
				
				dbDisplayView.setText(FinalProject.displayDB(database));
				dbDisplayView.revalidate();
				dbDisplayView.repaint();
			}
			else if(e.getSource() == deleteFieldButton) {
				
				if(itemFields.getSelectedItem() == "New Field") {
					return;
				}
				Item tmpItem;
				int choice = JOptionPane.showConfirmDialog(null, ("Are you sure you want to delete this field(" + itemFields.getSelectedItem() + ")?"),
						"Confirm Action", JOptionPane.YES_NO_CANCEL_OPTION);
				switch(choice) {
					
					case(JOptionPane.YES_OPTION):
						tmpItem = (Item)selectedItem.getSelectedItem();
						tmpItem.removeField((String) itemFields.getSelectedItem());
						JOptionPane.showMessageDialog(null, "Field deleted successfully");
						break;
					case(JOptionPane.NO_OPTION):
						JOptionPane.showMessageDialog(null, "field was not deleted");
						break;
					case(JOptionPane.CANCEL_OPTION):
						break;
				}
				
				dbDisplayView.setText(FinalProject.displayDB(database));
				dbDisplayView.revalidate();
				dbDisplayView.repaint();
			}
			else if(e.getSource() == deleteItemButton) {
				if(selectedItem.getSelectedItem() == "Add Item") {
					return;
				}
				Item tmpItem = (Item)selectedItem.getSelectedItem();;
				int choice = JOptionPane.showConfirmDialog(null, ("Are you sure you want to delete this Item(" + tmpItem + ")?"),
						"Confirm Action", JOptionPane.YES_NO_CANCEL_OPTION);
				switch(choice) {
					
					case(JOptionPane.YES_OPTION):
						 
						database.remove(tmpItem.getId());
						JOptionPane.showMessageDialog(null, "Field deleted successfully");
						break;
					case(JOptionPane.NO_OPTION):
						JOptionPane.showMessageDialog(null, "field was not deleted");
						break;
					case(JOptionPane.CANCEL_OPTION):
						break;
				}
				dbDisplayView.setText(FinalProject.displayDB(database));
				dbDisplayView.revalidate();
				dbDisplayView.repaint();
				populateItemBox();
			}

		}
	}
	
	class ComboBoxListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == selectedItem) {
				
				if(selectedItem.getSelectedItem() != "Add Item" && selectedItem.getSelectedItem() != null) {
					Item tempItem = (Item) selectedItem.getSelectedItem();
					itemFields.removeAllItems();
					itemNameInput.setText(tempItem.getName());
					for(Entry<String, Object> tmpEntry : tempItem.getAttributes().entrySet() ) {
						itemFields.addItem(tmpEntry.getKey());
						
					}
					itemFields.addItem("New Field");
				}else if(selectedItem.getSelectedItem() == "Add Item"){
					itemFields.removeAllItems();
					addItemBool = true;
					itemNameInput.setText("(Insert Name)");
					itemFields.addItem("New Field");
				}
				
				
			}
			else if(e.getSource() == itemFields) {
				if(itemFields.getSelectedItem() == "New Field") {
					itemFieldInput.setVisible(true);
					addField = true;
					
					itemFieldInput.revalidate();
					itemFieldInput.repaint();
					itemInput.revalidate();
					itemInput.repaint();
				}
				else {
					addField = false;
					itemFieldInput.setVisible(false);
					itemFieldInput.revalidate();
					itemFieldInput.repaint();
					itemInput.revalidate();
					itemInput.repaint();
				}
			}
		}
	}
}
