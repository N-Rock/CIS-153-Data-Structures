package view;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;

import finalProject.FinalProject;
import finalProject.Item;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Dictionary;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 * Nicolas Schoenrock - nvschoenrock@dmacc.edu CIS153 <14354> Dec 1, 2025
 * Description:
 * 
 * OS: [Windows 11] IDE: [eclipse 2023] Copyright : This is my own original work
 * based on specifications issued by our instructor Academic Honesty: I attest
 * that this is my original work. I have not used unauthorized source code,
 * either modified or unmodified, nor used generative AI as a final draft. I
 * have not given other fellow student(s) access to my program.
 * 
 */

public class MainDBWindow extends JPanel {

	Dictionary<Integer, Item> database;
	JLabel locationLabel;
	BoxLayout mainWinLayout = new BoxLayout(this, BoxLayout.Y_AXIS);
	JButton addEditButton;
	JButton saveButton;
	JButton loadButton;
	JFrame parentFrame;
	JComboBox<String> sortBox;
	JTextPane dbDisplayView;

	public MainDBWindow(Dictionary<Integer, Item> sourceDB, JFrame parentFrame) {
		super();
		this.database = sourceDB;
		this.parentFrame = parentFrame;
		JLabel locationLabel = new JLabel("Database View");

		ButtonListener mainWinButtonListen = new ButtonListener();
		ComboBoxListener mainwinCBListen = new ComboBoxListener();

		this.setLayout(mainWinLayout);
	
		saveButton = new JButton("Save Database");
		saveButton.addActionListener(mainWinButtonListen);
		loadButton = new JButton("load Database");
		loadButton.addActionListener(mainWinButtonListen);
		sortBox = new JComboBox<String>();
		sortBox.addActionListener(mainwinCBListen);
		
		buildSortBox();

		/*
		 * Display window setup. This should be where the active database query is.
		 * 
		 */
		JPanel displayWindow = new JPanel();
		dbDisplayView = new JTextPane();
		dbDisplayView.setEditable(false);
		dbDisplayView.setPreferredSize(new Dimension (800, 400));
		dbDisplayView.setMaximumSize(new Dimension(800, 400));
		Style dbWinStyle = dbDisplayView.addStyle("Center", null);
		StyleConstants.setAlignment(dbWinStyle, StyleConstants.ALIGN_CENTER);
		dbDisplayView.setText(FinalProject.displayDB(this.database));

		dbDisplayView.setParagraphAttributes(dbWinStyle, true);
		displayWindow.add(dbDisplayView);

		addEditButton = new JButton("Add/Edit item");

		addEditButton.addActionListener(mainWinButtonListen);

		this.setLayout(mainWinLayout);

		// Adding the Panels to the layout
		
		JPanel mwRow1 = new JPanel();
		mwRow1.setLayout(new BoxLayout(mwRow1, BoxLayout.X_AXIS));
		mwRow1.add(locationLabel);
		
		JPanel mwRow2 = new JPanel();
		mwRow2.setLayout(new BoxLayout(mwRow2, BoxLayout.X_AXIS));
		mwRow2.add(displayWindow);
		
		JPanel mwRow3 = new JPanel();
		mwRow3.setLayout(new BoxLayout(mwRow3, BoxLayout.X_AXIS));
		mwRow3.setPreferredSize(new Dimension(150, 25));
		sortBox.setMaximumSize(new Dimension(150, 50));
		mwRow3.add(Box.createHorizontalStrut(150));
		mwRow3.add(sortBox);
		mwRow3.add(Box.createHorizontalStrut(150));

		JPanel mwRow4 = new JPanel();
		mwRow4.setLayout(new BoxLayout(mwRow4, BoxLayout.X_AXIS));
		mwRow4.add(addEditButton);
		
		JPanel mwRow5 = new JPanel();
		mwRow5.setLayout(new BoxLayout(mwRow5, BoxLayout.X_AXIS));
		mwRow5.add(saveButton);
		mwRow5.add(loadButton);
		
		add(mwRow1);
		add(mwRow2);
		
		add(mwRow3);
		add(mwRow4);
		add(mwRow5);
		
		
		parentFrame.pack();
		parentFrame.setLocationRelativeTo(null);


	}

	/**
	 * @return
	 */
	
	
	private void buildSortBox() {
		sortBox.addItem(null);
		FinalProject.fieldsList = FinalProject.fetchFields(database);
		
		for(String field : FinalProject.fieldsList) {
			sortBox.addItem(field);
		}
		
	}
	

	class ButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// if statement checking the source of the action and acting accordingly
			if (e.getSource() == addEditButton) {
				JPanel nextPanel = new AddEditPanel(database, parentFrame);
				swapPanels(nextPanel);
			}
			else if(e.getSource() == saveButton) {
				try {
					FinalProject.saveDB(database);
					JOptionPane.showMessageDialog(null, "Database saved successfully");
				}catch (IOException exception){
					System.out.println(exception.getMessage());
					System.out.println("Source:");
					System.out.println(exception.getStackTrace());
				}
			}
			else if(e.getSource() == loadButton) {
				try {
					database = FinalProject.openDB("database.ser");
					FinalProject.displayDB(database);
					buildSortBox();
					
					repaint();
					revalidate();
				}catch(IOException | ClassNotFoundException ex) {
					System.out.println(ex.getMessage());
					System.out.println("Source:");
					System.out.println(ex.getStackTrace());
				}
				
			}

		}

	}
	class ComboBoxListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == sortBox) {
				dbDisplayView.setText(FinalProject.Query(database, (String)sortBox.getSelectedItem()));
				
			}
			
			
			
			
			}
		}
	
	
	private void swapPanels(JPanel nextPanel) {
		removeAll();
		setVisible(false);
		add(nextPanel);
		validate();
		setVisible(true);
	}
	
	
}

