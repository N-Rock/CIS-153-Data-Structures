/**  
* Nicolas Schoenrock - nvschoenrock@dmacc.edu 
* CIS153 <14354>
* Nov 16, 2025 
* Description: 
 
* OS: [Windows 11]
* IDE: [eclipse 2023]
* Copyright : This is my own original work 
* based on specifications issued by our instructor
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or
* unmodified, nor used generative AI as a final draft. 
* I have not given other fellow student(s) access to my program.

*/
package finalProject;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import javax.swing.*;

import view.MainDBWindow;


import java.util.Map.Entry;
import java.util.Set;

import java.io.*;

/**
 * 
 */

public class FinalProject {
	public static List<String> fieldsList;
	
	//retrieves all of the fields in the current database.
	public static List<String> fetchFields(Dictionary<Integer, Item> dbTable) {
		List<String> fields = new ArrayList<String>();
				
		//iterating through outer database dictionary
		Enumeration<Integer> keys = dbTable.keys();
		while (keys.hasMoreElements()) {
			int key = keys.nextElement();
		
			//iterating through the item for the current dictionary entry
			
			
			for(String itemKey : dbTable.get(key).getAttributes().keySet()) {
				if (!fields.contains(itemKey.toLowerCase())) {
					fields.add(itemKey);
				}
			}
			
		}
		return fields;
}
	// Displays all of the database entries at once.
	public static <K, V> String displayDB(Dictionary<Integer, Item> dbTable) {
		//list of fields pulled from the items, displayed at the top of the end String.
		List<String> fields = new ArrayList<String>();
		
		HashMap<Integer, Object> itemValues = new HashMap<>();
		
		String fieldString = "";
		String itemString ="";
		
		//iterating through outer database dictionary
		Enumeration<Integer> keys = dbTable.keys();
		while (keys.hasMoreElements()) {
			int key = keys.nextElement();
		
			//iterating through the item for the current dictionary entry
		
			for(String itemKey : dbTable.get(key).getAttributes().keySet()) {
				if (!fields.contains(itemKey.toLowerCase())) {
					fields.add(itemKey);
				}
			}
			
			
		}
		
		
		//re-iterating through the items with the fields list filled so it can formatt properly
		keys = dbTable.keys();
		while(keys.hasMoreElements()) {
			int key = keys.nextElement();
			
			//checking for whether the item has a value for the supplied field and building the final Strings accordingly
			for(int i = 0; i < fields.size(); i++) {
				if(dbTable.get(key).getAttributes().get(fields.get(i)) != null) {
					itemValues.put(i, dbTable.get(key).getAttributes().get(fields.get(i)));
				}
				else {
					itemValues.put(i, "N/A");
				}
				itemString += itemValues.get(i) + "  ";
			}
			itemString += "\n";
		
		}
		for(String field : fields) {
			fieldString += field + "  |  ";
		}
		

		String display = fieldString + "\n------------------------------------------------------------------------\n" 
				+ itemString;
		return display;
	}
	
	// retrieves items based on the supplied field and sorts them based on id. 
	public static String Query(Dictionary<Integer, Item> database, String fieldKey){
		Enumeration<Integer> dbKeys = database.keys();
		List<Integer> itemsList = new ArrayList<Integer>();
		while(dbKeys.hasMoreElements()) {
			int key = dbKeys.nextElement();
			Item keyItem = database.get(key);
			if(keyItem.getAttributes().containsKey(fieldKey.toLowerCase())) {
				itemsList.add(keyItem.getId());
			}
		}
		
		List<Item> itemValues = new ArrayList<Item>();
		String itemString = "";

		
		
		Object[] sortedIds = itemsList.toArray();
				mergeSort(sortedIds, 0, itemsList.size()-1);
		
		
		//creating a display
		
		for(int i = 0; i < sortedIds.length; i++) {
			itemValues.add(database.get(sortedIds[i]));
		}
		
		for(int i = 0; i < itemValues.size(); i++) {
			itemString += "id: " + itemValues.get(i).getId() + "  " + itemValues.get(i).getName() +  itemValues.get(i).getAttributes().toString() + "\n";
		}
		

		
		return itemString;
	}
	
	//Adds an item to the databse and supplies it with the currect id 
	public static boolean addItem(Dictionary<Integer, Item> database, Item item) {
		
		
		try{
			int currentDBID = database.size();
			item.setId(currentDBID);
			database.put(currentDBID, item);
			
		}catch(Exception e){
			return false;
		}
		
		return true;

	}


	
	
	//merges two arrays
	public static void mergeArray(Object[] objects, int left, int mid, int right) {
		
		int arrSize1 = mid - left + 1;
		int arrSize2 = right - mid;
		
		int lArr[] = new int [arrSize1];
		int rArr[] = new int [arrSize2];
		
		for(int i = 0; i < arrSize1; i++) {
			lArr[i] = (int) objects[left + i];
		}
		for(int n = 0; n < arrSize2; n++) {
			rArr[n] = (int) objects[mid + 1 + n];

		}
		
		int v =0; 
		int j=0;
		int k =left;
		
		while(v < arrSize1 && j < arrSize2) {
			if(lArr[v]<= rArr[j]) {
				objects[k] = lArr[v];
				v++;
			}
			else {
				objects[k] = rArr[j];
				j++;
			}
			k++;
		}
		
		while(v<arrSize1) {
			objects[k] = lArr[v];
			v++;
			k++;
		}
		
		while(j<arrSize2) {
			objects[k] = rArr[j];
			j++;
			k++;
		}
	}
	
	//splits up and sorts arrays until calling mergArray() to merge them back together.
	public static void mergeSort(Object[] objects, int left, int right) {
		if(left < right) {
			int mid = left + (right - left) /2;
			
			mergeSort(objects, left, mid);
			mergeSort(objects, mid + 1, right);
			
			mergeArray(objects, left, mid, right);
			
		}
	}
	
	//Save the current database to a database.ser file
	public static void saveDB(Dictionary<Integer, Item> database) throws IOException{
		FileOutputStream fileOut = new FileOutputStream("database.ser");
		ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
		
		objectOut.writeObject(database);
		objectOut.close();
	}
	
	
	//loads the database.ser file and builds the dictionary. 
	public static Dictionary<Integer, Item> openDB(String file) throws IOException, ClassNotFoundException {
		
		FileInputStream fileIn = new FileInputStream(file);
		ObjectInputStream objectIn = new ObjectInputStream(fileIn);
		
		Dictionary<Integer, Item> database = (Dictionary <Integer, Item>) objectIn.readObject();
		objectIn.close();
		return database;
	}
	
	/**
	 * @param args
	 */
	
	
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Dictionary<Integer, Item> database = new Hashtable<>();

	
		System.out.println(displayDB(database));
		
		// frame and panel creation 
		JFrame frame = new JFrame();
		MainDBWindow panel = new MainDBWindow(database, frame);
		frame.add(panel);

		frame.setSize(500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // making sure the program actually exits when you close
		frame.setVisible(true);
	}

}
