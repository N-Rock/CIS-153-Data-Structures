/**  
* Nicolas Schoenrock - nvschoenrock@dmacc.edu 
* CIS153 <14354>
* Oct 30, 2025 
* Description: 
 
* OS: [Windows 11]
* IDE: [eclipse 2023]
* Copyright : This is my own original work 
* based on specifications issued by our instructor
* Academic Honesty: I attest that this is my original work.
* I have not used unauthorized source code, either modified or
* unmodified, nor used generative AI as a final draft. 
* I have not given other fellow student(s) access to my program.

*/ 
package finalProject;

import java.io.Serializable;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
/**
 * 
 */


public class Item implements Serializable{
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	private String name;
	private int id;

	private HashMap<String, Object> attributes = new HashMap<>();
	private int attributeCount;
	
	@SafeVarargs
	public Item(String name, Tuple<String, ?>... keyValuePairs){
		this.setName(name);
		attributeCount = 0;
		for(Tuple<?, ?> kVP: keyValuePairs ) {
			attributes.put(((String) kVP.getFirst()).toLowerCase(), kVP.getSecond());
			attributeCount++;
		}
		
	}
	
	public void addField(String fieldName, Object value) {
		attributes.put(fieldName.toLowerCase(), value);
		attributeCount++;
		
		
	}
	
	public void removeField(String fieldName) {
		attributes.remove(fieldName);
		attributeCount--;
	}
	
	@Override
	public String toString() {
		return name + ", ID: " + id;
	}

	/**
	 * @return the attributes
	 */
	public HashMap<String, Object> getAttributes() {
		return attributes;
	}

	/**
	 * @param attributes the attributes to set
	 */
	public void setAttributes(HashMap<String, Object> attributes) {
		this.attributes = attributes;
	}

	/**
	 * @return the attributeCount
	 */
	public int getAttributeCount() {
		return attributeCount;
	}

	/**
	 * @param attributeCount the attributeCount to set
	 */
	public void setAttributeCount(int attributeCount) {
		this.attributeCount = attributeCount;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	
	/*public int compareTo(Item otherItem) {
		if(this.getId() != otherItem.getId()) {
			
		}
		
		return 0;
	}*/

}


